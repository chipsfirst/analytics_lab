#!/bin/sh
cd "$(dirname "$0")" || exit 1
PORT=8000
python3 -m http.server "$PORT" >/dev/null 2>&1 &
sleep 1
open "http://localhost:$PORT" 2>/dev/null || xdg-open "http://localhost:$PORT" 2>/dev/null
wait
